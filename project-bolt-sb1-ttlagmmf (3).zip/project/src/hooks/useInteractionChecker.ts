import { useState, useEffect } from 'react';
import { UserSupplement, InteractionResult } from '../types';
import { interactionDatabase } from '../data/interactions';
import { supplementDatabase } from '../data/supplements';

export const useInteractionChecker = (supplements: UserSupplement[]) => {
  const [interactions, setInteractions] = useState<InteractionResult[]>([]);

  useEffect(() => {
    if (supplements.length < 2) {
      setInteractions([]);
      return;
    }

    const results: InteractionResult[] = [];

    // Check all pairs of supplements
    for (let i = 0; i < supplements.length; i++) {
      for (let j = i + 1; j < supplements.length; j++) {
        const supp1 = supplements[i];
        const supp2 = supplements[j];

        // Look for interactions in both directions
        const interaction = interactionDatabase.find(
          inter =>
            (inter.supplement1 === supp1.id && inter.supplement2 === supp2.id) ||
            (inter.supplement1 === supp2.id && inter.supplement2 === supp1.id)
        );

        if (interaction) {
          // Get full supplement data
          const supplement1 = supplementDatabase.find(s => s.id === supp1.id);
          const supplement2 = supplementDatabase.find(s => s.id === supp2.id);

          if (supplement1 && supplement2) {
            results.push({
              interaction,
              supplements: [supplement1, supplement2]
            });
          }
        }
      }
    }

    setInteractions(results);
  }, [supplements]);

  return interactions;
};