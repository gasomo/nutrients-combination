import React from 'react';
import { AlertTriangle, CheckCircle, Info, Clock } from 'lucide-react';
import { InteractionResult, Interaction } from '../types';

interface InteractionResultsProps {
  results: InteractionResult[];
}

const getSeverityIcon = (severity: string) => {
  switch (severity) {
    case 'high':
      return <AlertTriangle className="text-red-500" size={20} />;
    case 'moderate':
      return <Info className="text-yellow-500" size={20} />;
    case 'low':
      return <CheckCircle className="text-green-500" size={20} />;
    default:
      return <Info className="text-gray-500" size={20} />;
  }
};

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'high':
      return 'border-red-200 bg-red-50';
    case 'moderate':
      return 'border-yellow-200 bg-yellow-50';
    case 'low':
      return 'border-green-200 bg-green-50';
    default:
      return 'border-gray-200 bg-gray-50';
  }
};

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'timing':
      return <Clock className="text-blue-500" size={16} />;
    case 'synergy':
      return <CheckCircle className="text-green-500" size={16} />;
    case 'competition':
      return <AlertTriangle className="text-orange-500" size={16} />;
    case 'conflict':
      return <AlertTriangle className="text-red-500" size={16} />;
    default:
      return <Info className="text-gray-500" size={16} />;
  }
};

export const InteractionResults: React.FC<InteractionResultsProps> = ({ results }) => {
  if (results.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="text-center py-8">
          <CheckCircle className="mx-auto text-green-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-700 mb-2">No interactions found</h3>
          <p className="text-gray-500">Your current supplement combination looks good!</p>
        </div>
      </div>
    );
  }

  const sortedResults = results.sort((a, b) => {
    const severityOrder = { high: 3, moderate: 2, low: 1 };
    return severityOrder[b.interaction.severity] - severityOrder[a.interaction.severity];
  });

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Interaction Analysis</h2>
      
      <div className="space-y-4">
        {sortedResults.map((result, index) => (
          <div
            key={index}
            className={`border-2 rounded-xl p-4 ${getSeverityColor(result.interaction.severity)}`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-2">
                {getSeverityIcon(result.interaction.severity)}
                <h3 className="font-semibold text-gray-800">
                  {result.supplements[0].name} + {result.supplements[1].name}
                </h3>
              </div>
              <div className="flex items-center space-x-1">
                {getTypeIcon(result.interaction.type)}
                <span className="text-xs uppercase font-medium text-gray-600">
                  {result.interaction.type}
                </span>
              </div>
            </div>
            
            <p className="text-gray-700 mb-3">{result.interaction.description}</p>
            
            <div className="bg-white bg-opacity-60 rounded-lg p-3">
              <h4 className="font-medium text-gray-800 mb-1">Recommendation:</h4>
              <p className="text-gray-700 text-sm">{result.interaction.recommendation}</p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-sm text-blue-800">
          <strong>Medical Disclaimer:</strong> This tool is for informational purposes only and should not replace professional medical advice. Always consult with a healthcare provider before starting, stopping, or changing any supplement regimen.
        </p>
      </div>
    </div>
  );
};