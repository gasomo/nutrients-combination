import React from 'react';
import { Trash2, Pill } from 'lucide-react';
import { UserSupplement } from '../types';

interface SupplementListProps {
  supplements: UserSupplement[];
  onRemoveSupplement: (id: string) => void;
}

export const SupplementList: React.FC<SupplementListProps> = ({ 
  supplements, 
  onRemoveSupplement 
}) => {
  if (supplements.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="text-center py-8">
          <Pill className="mx-auto text-gray-300 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-500 mb-2">No supplements added yet</h3>
          <p className="text-gray-400">Start by searching and adding your supplements above</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Your Supplement Stack</h2>
      <div className="space-y-3">
        {supplements.map((supplement) => (
          <div
            key={supplement.id}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <div className="flex-1">
              <h3 className="font-medium text-gray-800">{supplement.name}</h3>
              <p className="text-sm text-gray-600">{supplement.category}</p>
              {(supplement.dosage || supplement.frequency) && (
                <div className="flex gap-4 mt-1">
                  {supplement.dosage && (
                    <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                      {supplement.dosage}
                    </span>
                  )}
                  {supplement.frequency && (
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                      {supplement.frequency}
                    </span>
                  )}
                </div>
              )}
            </div>
            <button
              onClick={() => onRemoveSupplement(supplement.id)}
              className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-lg transition-colors"
            >
              <Trash2 size={18} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};