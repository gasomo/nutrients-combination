import React, { useState, useEffect } from 'react';
import { Shield, Heart, Brain, X, ExternalLink, CheckCircle, AlertTriangle, HelpCircle } from 'lucide-react';
import { UserSupplement } from './types';
import { SupplementSearch } from './components/SupplementSearch';
import { SupplementList } from './components/SupplementList';
import { InteractionResults } from './components/InteractionResults';
import { useInteractionChecker } from './hooks/useInteractionChecker';

function App() {
  const [userSupplements, setUserSupplements] = useState<UserSupplement[]>([]);
  const [showPopup, setShowPopup] = useState(false);
  const [showFAQ, setShowFAQ] = useState<number | null>(null);
  const interactions = useInteractionChecker(userSupplements);

  // Show popup after 10 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowPopup(true);
    }, 10000);
    return () => clearTimeout(timer);
  }, []);

  const handleAddSupplement = (supplement: UserSupplement) => {
    if (!userSupplements.find(s => s.id === supplement.id)) {
      setUserSupplements([...userSupplements, supplement]);
    }
  };

  const handleRemoveSupplement = (id: string) => {
    setUserSupplements(userSupplements.filter(s => s.id !== id));
  };

  const faqs = [
    {
      question: "How does the SupplementSafe tool work?",
      answer: "The SupplementSafe tool checks your supplements for bad mixes. You type in what you take. The tool looks at all your supplements together. It tells you if they are safe to take at the same time."
    },
    {
      question: "Is the SupplementSafe supplement checker free to use?",
      answer: "Yes! The SupplementSafe tool is 100% free. You can check as many supplements as you want. No sign up needed. Just start typing your supplements right on this page."
    },
    {
      question: "What supplements can I check with SupplementSafe?",
      answer: "SupplementSafe has many common supplements. We have vitamins like Vitamin D and C. We have minerals like iron and calcium. We also have herbs like turmeric. If you don't see yours, try typing different names for it."
    },
    {
      question: "Should I trust the SupplementSafe results?",
      answer: "SupplementSafe gives you good info to start with. But always talk to your doctor too. The tool helps you ask better questions. Your doctor knows your health best."
    },
    {
      question: "Can SupplementSafe replace my doctor's advice?",
      answer: "No! SupplementSafe is just a helper tool. Always talk to your doctor about supplements. This is extra important if you take medicine or have health problems."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Popup */}
      {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 relative">
            <button
              onClick={() => setShowPopup(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="text-green-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Want to Learn More About Supplements?
              </h3>
              <p className="text-gray-600 mb-6">
                Get expert tips and reviews at NutriRank USA. Learn which supplements really work!
              </p>
              <a
                href="https://nutrirankusa.store/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors inline-flex items-center space-x-2"
              >
                <span>Learn About Supplements</span>
                <ExternalLink size={16} />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Header with CTA */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-500 to-green-500 p-2 rounded-xl">
                <Shield className="text-white" size={28} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">SupplementSafe</h1>
                <p className="text-sm text-gray-600">Free supplement interaction checker</p>
              </div>
            </div>
            <a
              href="#supplement-tool"
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Check My Supplements Now
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            SupplementSafe: Free Supplement Interaction Checker Tool
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed mb-8">
            Are your supplements safe to take together? Use our free SupplementSafe tool to check if your vitamins and supplements mix well. Find out if they help each other or cause problems. Keep your health safe with smart supplement choices.
          </p>
          <a
            href="#supplement-tool"
            className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-colors inline-flex items-center space-x-2"
          >
            <Shield size={20} />
            <span>Start Checking Supplements Free</span>
          </a>
        </div>

        {/* Intro Paragraph */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-12">
          <p className="text-lg text-gray-700 leading-relaxed">
            Taking multiple supplements can be tricky. Some vitamins help each other work better. Others can block each other or cause bad side effects. The SupplementSafe tool on this page helps you check your supplement stack for free. Just type in what you take and see if they are safe together. No more guessing if your vitamins are helping or hurting you.
          </p>
        </div>
      </section>

      {/* Embedded Tool */}
      <section id="supplement-tool" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Use the SupplementSafe Checker Tool Below
          </h2>
          <p className="text-lg text-gray-600">
            Type your supplements in the box. The SupplementSafe tool will check them right away.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6 text-center">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-blue-600">{userSupplements.length}</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Your Supplements</h3>
            <p className="text-gray-600">Supplements you added to check</p>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6 text-center">
            <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-yellow-600">{interactions.length}</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Interactions Found</h3>
            <p className="text-gray-600">Possible problems the tool found</p>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6 text-center">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-green-600">12</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Supplements in Database</h3>
            <p className="text-gray-600">Common vitamins and supplements</p>
          </div>
        </div>

        {/* Tool Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div className="space-y-6">
            <SupplementSearch onAddSupplement={handleAddSupplement} />
            <SupplementList 
              supplements={userSupplements} 
              onRemoveSupplement={handleRemoveSupplement} 
            />
          </div>
          <div>
            <InteractionResults results={interactions} />
          </div>
        </div>
      </section>

      {/* How to Use Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            How to Use the SupplementSafe Tool
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Type Your SupplementSafe List
              </h3>
              <p className="text-gray-600">
                Use the search box above on this page. Type each supplement you take. The SupplementSafe tool will find it for you. Add how much you take too.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-yellow-600">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Let SupplementSafe Check for Problems
              </h3>
              <p className="text-gray-600">
                The SupplementSafe tool looks at all your supplements together. It finds problems like bad mixes or timing issues. This happens right away on this page.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-green-600">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Follow SupplementSafe Tips
              </h3>
              <p className="text-gray-600">
                The SupplementSafe tool gives you easy tips. It tells you when to take each supplement. It warns you about bad mixes. Use these tips to stay safe.
              </p>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              SupplementSafe Color Guide
            </h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <CheckCircle className="text-green-500" size={20} />
                <span className="text-gray-700"><strong>Green:</strong> Your supplements are safe to take together</span>
              </div>
              <div className="flex items-center space-x-3">
                <AlertTriangle className="text-yellow-500" size={20} />
                <span className="text-gray-700"><strong>Yellow:</strong> Take these supplements at different times</span>
              </div>
              <div className="flex items-center space-x-3">
                <AlertTriangle className="text-red-500" size={20} />
                <span className="text-gray-700"><strong>Red:</strong> These supplements might cause problems together</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Why Use the SupplementSafe Interaction Checker?
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <Heart className="text-red-500 mb-4" size={32} />
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              Keep Your Health Safe with SupplementSafe
            </h3>
            <p className="text-gray-600">
              Some supplements can hurt you when mixed wrong. The SupplementSafe tool on this page helps you avoid these problems. Stay healthy by checking your supplements first.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <Brain className="text-purple-500 mb-4" size={32} />
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              Make Smart SupplementSafe Choices
            </h3>
            <p className="text-gray-600">
              Don't guess about your supplements. The SupplementSafe checker gives you real facts. Make smart choices based on what the tool tells you.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <Shield className="text-green-500 mb-4" size={32} />
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              Free SupplementSafe Tool Always Available
            </h3>
            <p className="text-gray-600">
              The SupplementSafe tool is free to use anytime. Come back to this page whenever you start new supplements. Check them before you take them.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <CheckCircle className="text-blue-500 mb-4" size={32} />
            <h3 className="text-xl font-semibold text-gray-800 mb-3">
              Easy SupplementSafe Results to Understand
            </h3>
            <p className="text-gray-600">
              No hard words or confusing info. The SupplementSafe tool uses simple colors and easy words. Anyone can understand what it means.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            SupplementSafe Tool Questions and Answers
          </h2>
          
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-gray-200 rounded-lg">
                <button
                  onClick={() => setShowFAQ(showFAQ === index ? null : index)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50"
                >
                  <span className="font-semibold text-gray-800">{faq.question}</span>
                  <HelpCircle className={`text-gray-400 transform transition-transform ${showFAQ === index ? 'rotate-180' : ''}`} size={20} />
                </button>
                {showFAQ === index && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-xl shadow-lg p-8 text-white text-center">
          <Shield className="mx-auto mb-6" size={48} />
          <h2 className="text-3xl font-bold mb-4">
            Start Using SupplementSafe Today
          </h2>
          <p className="text-xl opacity-90 max-w-3xl mx-auto leading-relaxed mb-8">
            Don't take chances with your health. Use the free SupplementSafe tool on this page right now. Check if your supplements are safe to take together. It only takes a few minutes.
          </p>
          <a
            href="#supplement-tool"
            className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors inline-flex items-center space-x-2"
          >
            <Shield size={20} />
            <span>Check My Supplements Now</span>
          </a>
        </div>
      </section>

      {/* Safety Notice */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="text-yellow-600 flex-shrink-0 mt-1" size={20} />
            <div>
              <h3 className="font-semibold text-yellow-800 mb-2">Important SupplementSafe Safety Note</h3>
              <p className="text-yellow-700 text-sm">
                The SupplementSafe tool gives you helpful info but is not medical advice. Always talk to your doctor about supplements, especially if you take medicine or have health problems. This tool helps you ask better questions but cannot replace your doctor's advice.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Shield className="text-blue-400" size={24} />
              <span className="text-xl font-bold">SupplementSafe</span>
            </div>
            <p className="text-gray-400 mb-4">
              Free supplement interaction checker tool for everyone
            </p>
            <div className="text-sm text-gray-500">
              <p>© 2025 SupplementSafe. Free tool for educational use only.</p>
              <p className="mt-2">Always talk to your doctor about supplements and health.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;