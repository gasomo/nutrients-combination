import { Supplement } from '../types';

export const supplementDatabase: Supplement[] = [
  {
    id: 'vitamin-d3',
    name: 'Vitamin D3',
    category: 'Fat-Soluble Vitamins',
    commonNames: ['Cholecalciferol', 'Vitamin D'],
    description: 'Essential for bone health and immune function'
  },
  {
    id: 'magnesium-glycinate',
    name: 'Magnesium Glycinate',
    category: 'Minerals',
    commonNames: ['Magnesium', 'Mg Glycinate'],
    description: 'Highly bioavailable form of magnesium for muscle and nerve function'
  },
  {
    id: 'calcium-carbonate',
    name: 'Calcium Carbonate',
    category: 'Minerals',
    commonNames: ['Calcium', 'Ca Carbonate'],
    description: 'Essential mineral for bone and teeth health'
  },
  {
    id: 'iron-sulfate',
    name: 'Iron Sulfate',
    category: 'Minerals',
    commonNames: ['Iron', 'Fe Sulfate'],
    description: 'Essential for blood formation and oxygen transport'
  },
  {
    id: 'zinc-picolinate',
    name: 'Zinc Picolinate',
    category: 'Minerals',
    commonNames: ['Zinc', 'Zn Picolinate'],
    description: 'Important for immune function and wound healing'
  },
  {
    id: 'copper-gluconate',
    name: 'Copper Gluconate',
    category: 'Minerals',
    commonNames: ['Copper', 'Cu Gluconate'],
    description: 'Essential trace mineral for iron metabolism'
  },
  {
    id: 'vitamin-c',
    name: 'Vitamin C',
    category: 'Water-Soluble Vitamins',
    commonNames: ['Ascorbic Acid', 'L-Ascorbic Acid'],
    description: 'Powerful antioxidant supporting immune function'
  },
  {
    id: 'vitamin-k2',
    name: 'Vitamin K2',
    category: 'Fat-Soluble Vitamins',
    commonNames: ['Menaquinone', 'MK-7'],
    description: 'Important for bone health and calcium metabolism'
  },
  {
    id: 'ashwagandha',
    name: 'Ashwagandha',
    category: 'Herbs & Adaptogens',
    commonNames: ['Withania Somnifera', 'Indian Winter Cherry'],
    description: 'Adaptogenic herb for stress management and energy'
  },
  {
    id: 'turmeric',
    name: 'Turmeric',
    category: 'Herbs & Adaptogens',
    commonNames: ['Curcuma Longa', 'Curcumin'],
    description: 'Anti-inflammatory herb with antioxidant properties'
  },
  {
    id: 'omega-3',
    name: 'Omega-3 Fish Oil',
    category: 'Fatty Acids',
    commonNames: ['Fish Oil', 'EPA DHA'],
    description: 'Essential fatty acids for heart and brain health'
  },
  {
    id: 'probiotics',
    name: 'Probiotics',
    category: 'Digestive Health',
    commonNames: ['Live Cultures', 'Beneficial Bacteria'],
    description: 'Live microorganisms supporting digestive health'
  }
];