import { Interaction } from '../types';

export const interactionDatabase: Interaction[] = [
  {
    supplement1: 'calcium-carbonate',
    supplement2: 'iron-sulfate',
    severity: 'moderate',
    type: 'competition',
    description: 'Calcium can significantly reduce iron absorption when taken together.',
    recommendation: 'Take calcium and iron at least 2-3 hours apart. Consider taking iron on an empty stomach with vitamin C.'
  },
  {
    supplement1: 'zinc-picolinate',
    supplement2: 'copper-gluconate',
    severity: 'moderate',
    type: 'competition',
    description: 'High doses of zinc can interfere with copper absorption and may lead to copper deficiency over time.',
    recommendation: 'Take zinc and copper at least 2 hours apart, or ensure copper intake when supplementing with high-dose zinc.'
  },
  {
    supplement1: 'vitamin-d3',
    supplement2: 'magnesium-glycinate',
    severity: 'low',
    type: 'synergy',
    description: 'Magnesium helps convert vitamin D to its active form and improves absorption.',
    recommendation: 'These supplements work well together and can be taken at the same time.'
  },
  {
    supplement1: 'vitamin-d3',
    supplement2: 'vitamin-k2',
    severity: 'low',
    type: 'synergy',
    description: 'Vitamin K2 works synergistically with vitamin D3 for optimal calcium metabolism and bone health.',
    recommendation: 'These fat-soluble vitamins complement each other perfectly and should be taken together with a meal.'
  },
  {
    supplement1: 'vitamin-c',
    supplement2: 'iron-sulfate',
    severity: 'low',
    type: 'synergy',
    description: 'Vitamin C significantly enhances iron absorption, especially non-heme iron.',
    recommendation: 'Take these together on an empty stomach for maximum iron absorption.'
  },
  {
    supplement1: 'calcium-carbonate',
    supplement2: 'magnesium-glycinate',
    severity: 'moderate',
    type: 'competition',
    description: 'High doses of calcium can interfere with magnesium absorption.',
    recommendation: 'Maintain a 2:1 calcium to magnesium ratio. Consider taking them at different times if using high doses.'
  },
  {
    supplement1: 'zinc-picolinate',
    supplement2: 'iron-sulfate',
    severity: 'moderate',
    type: 'competition',
    description: 'Zinc and iron compete for the same absorption pathways in the digestive system.',
    recommendation: 'Take zinc and iron at least 2 hours apart for optimal absorption of both minerals.'
  },
  {
    supplement1: 'ashwagandha',
    supplement2: 'turmeric',
    severity: 'low',
    type: 'synergy',
    description: 'Both herbs have complementary anti-inflammatory and stress-reducing properties.',
    recommendation: 'These adaptogens work well together and can be taken simultaneously.'
  },
  {
    supplement1: 'omega-3',
    supplement2: 'vitamin-d3',
    severity: 'low',
    type: 'synergy',
    description: 'Fat-soluble vitamins like vitamin D are better absorbed when taken with healthy fats.',
    recommendation: 'Take vitamin D with omega-3 or other healthy fats for improved absorption.'
  },
  {
    supplement1: 'probiotics',
    supplement2: 'vitamin-c',
    severity: 'moderate',
    type: 'timing',
    description: 'High doses of vitamin C may affect the survival of probiotic bacteria.',
    recommendation: 'Take probiotics and vitamin C at least 2-3 hours apart to ensure probiotic viability.'
  }
];