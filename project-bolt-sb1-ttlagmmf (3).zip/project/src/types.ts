export interface Supplement {
  id: string;
  name: string;
  category: string;
  commonNames: string[];
  description: string;
}

export interface UserSupplement extends Supplement {
  dosage?: string;
  frequency?: string;
}

export interface Interaction {
  supplement1: string;
  supplement2: string;
  severity: 'low' | 'moderate' | 'high';
  type: 'competition' | 'synergy' | 'timing' | 'conflict';
  description: string;
  recommendation: string;
}

export interface InteractionResult {
  interaction: Interaction;
  supplements: [Supplement, Supplement];
}